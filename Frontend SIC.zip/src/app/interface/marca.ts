import { Identifiers } from "@angular/compiler";

export interface Marca {
    id?: Number;
    marca:string;    
}
