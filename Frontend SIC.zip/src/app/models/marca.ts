import { Identifiers } from "@angular/compiler";

export class Marca {
    id?: Number;
    marca:string;    
}

constructor(marca:String){
    this.marca=marca;
}
